import { useState, useEffect, useRef } from 'react';
import { motion, useScroll, useTransform, AnimatePresence } from 'motion/react';
import { 
  TrendingUp, 
  CheckCircle2, 
  Users, 
  PlayCircle, 
  ShieldCheck, 
  Zap, 
  Clock, 
  ArrowRight, 
  Star,
  MessageCircle,
  BarChart3,
  GraduationCap,
  Send,
  Flame,
  X
} from 'lucide-react';

// --- Sales triggers ---

const Countdown = () => {
  const target = useRef<number>(Date.now() + 1000 * 60 * 60 * 23 + 1000 * 60 * 47);
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const i = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(i);
  }, []);

  const diff = Math.max(0, target.current - now);
  const h = String(Math.floor(diff / 3600000)).padStart(2, "0");
  const m = String(Math.floor((diff % 3600000) / 60000)).padStart(2, "0");
  const s = String(Math.floor((diff % 60000) / 1000)).padStart(2, "0");

  const Box = ({ v, label }: { v: string; label: string }) => (
    <div className="flex flex-col items-center">
      <div className="bg-black border border-neon-green/40 rounded-xl px-4 py-3 min-w-[70px] text-center">
        <span className="text-3xl md:text-4xl font-black text-neon-green text-glow-green tabular-nums">{v}</span>
      </div>
      <span className="text-[10px] uppercase tracking-widest text-gray-500 mt-2">{label}</span>
    </div>
  );

  return (
    <div className="flex items-center justify-center gap-3 md:gap-4">
      <Box v={h} label="Horas" />
      <span className="text-3xl text-neon-green font-black">:</span>
      <Box v={m} label="Min" />
      <span className="text-3xl text-neon-green font-black">:</span>
      <Box v={s} label="Seg" />
    </div>
  );
};

const StickyCTA = () => {
  const [visible, setVisible] = useState(false);
  const [closed, setClosed] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 600);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <AnimatePresence>
      {visible && !closed && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          className="fixed bottom-0 left-0 right-0 z-50 bg-gradient-to-r from-neon-green to-emerald-400 text-black border-t border-black/20 shadow-2xl"
        >
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <Flame className="w-6 h-6 flex-shrink-0 animate-pulse" />
              <p className="text-sm md:text-base font-black truncate">
                APENAS R$67/mês — vagas limitadas hoje!
              </p>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <a
                href="https://pay.cakto.com.br/q9qmxv5"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-black text-neon-green px-4 md:px-6 py-2 rounded-full font-black text-sm md:text-base hover:scale-105 transition-transform whitespace-nowrap"
              >
                ENTRAR AGORA
              </a>
              <button
                onClick={() => setClosed(true)}
                className="p-1 hover:bg-black/10 rounded-full transition-colors"
                aria-label="Fechar"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

const FloatingWhatsApp = () => (
  <motion.a
    href="https://wa.me/5562981524626"
    target="_blank"
    rel="noopener noreferrer"
    initial={{ scale: 0 }}
    animate={{ scale: 1 }}
    transition={{ delay: 1.5, type: "spring" }}
    whileHover={{ scale: 1.1 }}
    whileTap={{ scale: 0.95 }}
    className="fixed bottom-4 right-4 z-[55] w-14 h-14 rounded-full bg-[#25D366] text-white flex items-center justify-center shadow-2xl"
    style={{ boxShadow: "0 0 20px rgba(37,211,102,0.5)" }}
    aria-label="Falar no WhatsApp"
  >
    <MessageCircle className="w-6 h-6" />
    <span className="absolute inset-0 rounded-full bg-[#25D366] animate-ping opacity-30" />
  </motion.a>
);

// --- Components ---

const Navbar = () => {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-md border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-neon-green rounded flex items-center justify-center shadow-[0_0_10px_rgba(0,255,136,0.5)]">
              <TrendingUp className="text-black w-5 h-5" />
            </div>
            <span className="text-xl font-bold tracking-tighter text-glow-green">FX VIP WA</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm font-medium">
            <a href="#receber" className="hover:text-neon-green transition-colors">O que você recebe</a>
            <a href="#resultados" className="hover:text-neon-green transition-colors">Resultados</a>
            <a href="#depoimentos" className="hover:text-neon-green transition-colors">Depoimentos</a>
            <a href="#planos" className="hover:text-neon-green transition-colors">Planos</a>
          </div>
          <a 
            href="#planos" 
            className="bg-neon-green text-black px-4 py-2 rounded-full text-sm font-bold hover:scale-105 transition-transform glow-green"
          >
            ENTRAR AGORA
          </a>
        </div>
      </div>
    </nav>
  );
};

const Counter = ({ value, prefix = "+$" }: { value: number, prefix?: string }) => {
  const [count, setCount] = useState(0);
  
  useEffect(() => {
    let start = 0;
    const end = value;
    const duration = 2000;
    const increment = end / (duration / 16);
    
    const timer = setInterval(() => {
      start += increment;
      if (start >= end) {
        setCount(end);
        clearInterval(timer);
      } else {
        setCount(Math.floor(start));
      }
    }, 16);
    
    return () => clearInterval(timer);
  }, [value]);

  return <span>{prefix}{count.toLocaleString()}</span>;
};

const CandlestickChart = () => {
  return (
    <div className="absolute inset-0 overflow-hidden opacity-20 pointer-events-none">
      <div className="flex items-end gap-1 h-full w-full justify-around p-4">
        {Array.from({ length: 40 }).map((_, i) => (
          <motion.div
            key={i}
            initial={{ height: 0 }}
            animate={{ height: `${Math.random() * 60 + 20}%` }}
            transition={{ duration: 2, repeat: Infinity, repeatType: 'reverse', delay: i * 0.1 }}
            className={`w-1 rounded-full ${Math.random() > 0.5 ? 'bg-neon-green' : 'bg-red-500'}`}
          />
        ))}
      </div>
    </div>
  );
};

const LiveProfitTicker = () => {
  const [profit, setProfit] = useState(120);

  useEffect(() => {
    const interval = setInterval(() => {
      setProfit(prev => prev + Math.floor(Math.random() * 50) + 10);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-neon-green/10 border-y border-neon-green/20 py-3 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-center gap-2 md:gap-4">
        <span className="text-gray-400 text-xs font-bold uppercase tracking-widest">Lucros gerados pelos alunos hoje:</span>
        <motion.div 
          key={profit}
          initial={{ scale: 1.1, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="text-neon-green text-2xl md:text-3xl font-black text-glow-green"
        >
          +${profit.toLocaleString()}
        </motion.div>
      </div>
    </div>
  );
};

const ProfitGraph = ({ type }: { type: 'before' | 'after' }) => {
  const points = type === 'before' 
    ? [20, 25, 22, 28, 24, 30, 26, 32] 
    : [20, 25, 35, 50, 45, 70, 85, 100];
  
  return (
    <div className="relative w-full h-full bg-black p-6 flex flex-col justify-between">
      <div className="flex justify-between items-start">
        <span className={`text-xs font-bold uppercase tracking-widest ${type === 'before' ? 'text-gray-500' : 'text-neon-green'}`}>
          {type === 'before' ? 'ANTES' : 'DEPOIS'}
        </span>
        <span className={`text-xl font-black ${type === 'before' ? 'text-gray-500' : 'text-neon-green text-glow-green'}`}>
          {type === 'before' ? '+$120' : '+$1,240'}
        </span>
      </div>
      
      <div className="relative h-48 w-full mt-4">
        <svg viewBox="0 0 100 100" className="w-full h-full overflow-visible" preserveAspectRatio="none">
          <defs>
            <linearGradient id={`grad-${type}`} x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor={type === 'before' ? '#4b5563' : '#00ff88'} stopOpacity="0.3" />
              <stop offset="100%" stopColor={type === 'before' ? '#4b5563' : '#00ff88'} stopOpacity="0" />
            </linearGradient>
          </defs>
          
          {/* Area */}
          <motion.path
            d={`M 0 100 ${points.map((p, i) => `L ${(i / (points.length - 1)) * 100} ${100 - p}`).join(' ')} L 100 100 Z`}
            fill={`url(#grad-${type})`}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 1 }}
          />
          
          {/* Line */}
          <motion.path
            d={`M 0 ${100 - points[0]} ${points.slice(1).map((p, i) => `L ${((i + 1) / (points.length - 1)) * 100} ${100 - p}`).join(' ')}`}
            fill="none"
            stroke={type === 'before' ? '#4b5563' : '#00ff88'}
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
            initial={{ pathLength: 0 }}
            whileInView={{ pathLength: 1 }}
            transition={{ duration: 2, ease: "easeInOut" }}
            style={{ filter: type === 'after' ? 'drop-shadow(0 0 8px #00ff88)' : 'none' }}
          />
          
          {/* Points */}
          {points.map((p, i) => (
            <motion.circle
              key={i}
              cx={(i / (points.length - 1)) * 100}
              cy={100 - p}
              r="2"
              fill={type === 'before' ? '#4b5563' : '#00ff88'}
              initial={{ scale: 0 }}
              whileInView={{ scale: 1 }}
              transition={{ delay: (i / points.length) * 1.5 }}
            />
          ))}
        </svg>
      </div>
    </div>
  );
};

const Hero = () => {
  return (
    <section className="relative min-h-screen flex flex-col pt-20 overflow-hidden">
      <LiveProfitTicker />
      <div className="flex-1 flex items-center justify-center relative">
        <CandlestickChart />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center py-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="inline-block px-4 py-1 rounded-full bg-white/5 border border-white/10 text-gold text-xs font-bold tracking-widest mb-6 uppercase">
              Acesso Exclusivo
            </span>
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-black tracking-tighter mb-6 leading-none">
              VOCÊ NÃO ESTÁ <br />
              <span className="text-neon-green text-glow-green italic">AQUI POR ACASO.</span>
            </h1>
            <p className="text-lg md:text-2xl text-gray-400 max-w-3xl mx-auto mb-10 leading-relaxed">
              Você está aqui porque quer lucrar — e vai lucrar com quem sabe o que está fazendo.
            </p>
            
            <div className="flex flex-col md:flex-row items-center justify-center gap-6 mb-12">
              <div className="flex flex-col items-center">
                <span className="text-neon-green text-3xl font-bold">
                  <Counter value={930} />
                </span>
                <span className="text-xs text-gray-500 uppercase tracking-widest">Lucro Hoje</span>
              </div>
              <div className="w-px h-12 bg-white/10 hidden md:block" />
              <div className="flex flex-col items-center">
                <span className="text-gold text-3xl font-bold">
                  <Counter value={480} />
                </span>
                <span className="text-xs text-gray-500 uppercase tracking-widest">Lucro Ontem</span>
              </div>
              <div className="w-px h-12 bg-white/10 hidden md:block" />
              <div className="flex flex-col items-center">
                <span className="text-neon-green text-3xl font-bold">
                  <Counter value={120} />
                </span>
                <span className="text-xs text-gray-500 uppercase tracking-widest">Última Operação</span>
              </div>
            </div>

            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#25D366]/15 border border-[#25D366]/40">
                <MessageCircle className="w-4 h-4 text-[#25D366]" />
                <span className="text-sm font-bold text-white">Grupo VIP no WhatsApp</span>
              </div>
              <h2 className="text-2xl font-bold text-white">FX VIP WA</h2>
              <p className="text-gray-400 max-w-2xl mx-auto">
                O grupo de sinais com até <span className="text-neon-green font-bold">90% de assertividade</span> na abertura do mercado Forex.
                Operações ao vivo <span className="text-neon-green font-bold">Domingo e Segunda, das 19h às 22h</span>, direto de um trader com mais de 6 anos de experiência.
              </p>
            </div>

            <motion.div 
              className="mt-12"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <a 
                href="#planos" 
                className="inline-flex items-center gap-3 bg-neon-green text-black text-xl font-black px-10 py-6 rounded-2xl glow-green hover:bg-white transition-all group"
              >
                ENTRAR NO GRUPO VIP AGORA
                <ArrowRight className="group-hover:translate-x-2 transition-transform" />
              </a>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const Features = () => {
  const features = [
    {
      icon: <Zap className="w-8 h-8 text-neon-green" />,
      title: "Sinais ao Vivo",
      desc: "Validados na abertura do mercado (domingo)."
    },
    {
      icon: <TrendingUp className="w-8 h-8 text-neon-green" />,
      title: "Alta Assertividade",
      desc: "Estratégia com 80% a 90% de taxa de acerto."
    },
    {
      icon: <GraduationCap className="w-8 h-8 text-neon-green" />,
      title: "Aula Gravada",
      desc: "Ensinando toda a configuração inicial passo a passo."
    },
    {
      icon: <MessageCircle className="w-8 h-8 text-neon-green" />,
      title: "Suporte VIP no WhatsApp",
      desc: "Suporte direto dentro do grupo no WhatsApp para tirar dúvidas."
    },
    {
      icon: <ShieldCheck className="w-8 h-8 text-neon-green" />,
      title: "Operações Guiadas",
      desc: "Tudo o que você precisa fazer é copiar e colar."
    }
  ];

  return (
    <section id="receber" className="py-24 bg-zinc-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-black mb-4">O QUE VOCÊ VAI RECEBER</h2>
          <div className="w-24 h-1 bg-neon-green mx-auto rounded-full" />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((f, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              viewport={{ once: true }}
              className="p-8 rounded-3xl bg-black border border-white/5 hover:border-neon-green/30 transition-all group"
            >
              <div className="mb-6 p-4 rounded-2xl bg-white/5 inline-block group-hover:scale-110 transition-transform">
                {f.icon}
              </div>
              <h3 className="text-xl font-bold mb-3">{f.title}</h3>
              <p className="text-gray-500 leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Results = () => {
  return (
    <section id="resultados" className="py-24 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          <div className="lg:w-1/2">
            <h2 className="text-4xl md:text-6xl font-black mb-6 leading-tight">
              RESULTADOS REAIS DE <br />
              <span className="text-gold text-glow-gold">QUEM ESTÁ DENTRO</span>
            </h2>
            <p className="text-xl text-gray-400 mb-8">
              Enquanto muitos tentam adivinhar, nossos alunos seguem um método validado.
            </p>
            <div className="space-y-6">
              {[
                "Lucros consistentes semana após semana",
                "Gestão de risco profissional",
                "Liberdade para operar de onde quiser"
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-4">
                  <CheckCircle2 className="text-neon-green w-6 h-6 flex-shrink-0" />
                  <span className="text-lg font-medium">{item}</span>
                </div>
              ))}
            </div>
          </div>
          
          <div className="lg:w-1/2 grid grid-cols-1 md:grid-cols-2 gap-6">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              className="aspect-[4/3] md:aspect-[4/5] bg-black rounded-3xl border border-white/10 overflow-hidden relative group glow-gold/10"
            >
              <ProfitGraph type="before" />
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
              className="aspect-[4/3] md:aspect-[4/5] bg-black rounded-3xl border border-neon-green/30 overflow-hidden relative group glow-green/20"
            >
              <ProfitGraph type="after" />
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

const Testimonials = () => {
  const videos = [
    "https://www.youtube.com/embed/YKCYiH43bso",
    "https://www.youtube.com/embed/qsT2Nial5FY",
    "https://www.youtube.com/embed/eRBeW-gjjqI",
    "https://www.youtube.com/embed/LBwkqbj7_Uk"
  ];

  return (
    <section id="depoimentos" className="py-24 bg-zinc-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-black mb-4 uppercase tracking-tighter">VEJA QUEM JÁ ESTÁ LUCRANDO</h2>
          <p className="text-gray-500">Depoimentos reais de alunos do FX VIP WA</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {videos.map((v, i) => (
            <div key={i} className="aspect-video rounded-3xl overflow-hidden border border-white/10 bg-black shadow-2xl">
              <iframe 
                className="w-full h-full"
                src={v} 
                title={`Depoimento ${i + 1}`}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowFullScreen
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Pricing = () => {
  const features = [
    "Acesso ao grupo VIP no WhatsApp",
    "Sinais ao vivo nas operações",
    "Suporte direto do trader",
    "Aula gravada com toda a configuração",
    "Operações guiadas: copiar e colar",
  ];

  return (
    <section id="planos" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-4xl md:text-6xl font-black mb-4">ESCOLHA SEU PLANO E COMECE A LUCRAR</h2>
          <p className="text-gold font-bold tracking-widest uppercase text-sm">Vagas Limitadas</p>
        </div>

        <div className="max-w-2xl mx-auto mb-10 space-y-5">
          <div className="flex items-center justify-center gap-3 p-5 rounded-2xl bg-neon-green/10 border border-neon-green/30">
            <Clock className="text-neon-green w-6 h-6 flex-shrink-0" />
            <p className="text-center font-bold text-white">
              Operações ao vivo: <span className="text-neon-green">Domingo e Segunda, das 19h às 22h</span>
            </p>
          </div>

          <div className="text-center">
            <p className="text-xs uppercase tracking-widest text-red-500 font-bold mb-3 flex items-center justify-center gap-2">
              <Flame className="w-4 h-4 animate-pulse" /> A oferta termina em
            </p>
            <Countdown />
          </div>

          <div>
            <div className="flex justify-between text-xs font-bold uppercase tracking-widest mb-2">
              <span className="text-gray-400">Vagas restantes</span>
              <span className="text-red-500">7 / 50</span>
            </div>
            <div className="h-2 bg-white/5 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                whileInView={{ width: "86%" }}
                transition={{ duration: 1.5, ease: "easeOut" }}
                viewport={{ once: true }}
                className="h-full bg-gradient-to-r from-red-500 to-red-400"
              />
            </div>
          </div>
        </div>

        <div className="max-w-md mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="relative p-8 rounded-[2.5rem] border bg-gradient-to-b from-zinc-900 to-black border-neon-green glow-green"
          >
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-neon-green text-black text-xs font-black px-4 py-1 rounded-full">
              ACESSO VIP
            </div>

            <div className="text-center mb-8">
              <h3 className="text-xl font-bold text-gray-400 mb-2">Plano VIP Mensal</h3>
              <div className="flex items-center justify-center gap-1">
                <span className="text-2xl font-bold">R$</span>
                <span className="text-7xl font-black text-glow-green">67</span>
              </div>
              <p className="text-neon-green font-bold mt-2">por mês</p>
              <p className="text-gray-500 mt-2">Tudo o que você precisa para começar</p>
            </div>

            <div className="space-y-4 mb-10">
              {features.map((f, j) => (
                <div key={j} className="flex items-center gap-3">
                  <CheckCircle2 className="text-neon-green w-5 h-5 flex-shrink-0" />
                  <span className="text-sm font-medium text-gray-300">{f}</span>
                </div>
              ))}
            </div>

            <motion.a
              href="https://pay.cakto.com.br/q9qmxv5"
              target="_blank"
              rel="noopener noreferrer"
              animate={{ boxShadow: ["0 0 15px rgba(0,255,136,0.4)", "0 0 35px rgba(0,255,136,0.8)", "0 0 15px rgba(0,255,136,0.4)"] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="block w-full py-5 rounded-2xl text-center font-black text-lg transition-all bg-neon-green text-black hover:bg-white"
            >
              QUERO ENTRAR NO GRUPO VIP AGORA
            </motion.a>

            <div className="mt-5 flex items-center justify-center gap-2 text-xs text-gray-400">
              <ShieldCheck className="w-4 h-4 text-neon-green" />
              Garantia incondicional de 7 dias
            </div>
          </motion.div>
        </div>

        <div className="mt-16 text-center">
          <div className="inline-flex flex-col items-center gap-4 p-8 rounded-3xl bg-red-500/10 border border-red-500/20">
            <Clock className="text-red-500 w-8 h-8 animate-pulse" />
            <div className="space-y-1">
              <p className="text-xl font-black text-red-500 uppercase">ATENÇÃO: Valor promocional por tempo limitado.</p>
              <p className="text-gray-400">O preço pode aumentar a qualquer momento. Quem entra agora sai na frente.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const ObjectionHandling = () => {
  return (
    <section className="py-24 bg-zinc-950 border-y border-white/5">
      <div className="max-w-4xl mx-auto px-4 text-center">
        <h2 className="text-3xl md:text-5xl font-black mb-8 leading-tight">
          "Você não precisa entender tudo de Forex. <br />
          <span className="text-neon-green">Você só precisa seguir quem sabe o que está fazendo."</span>
        </h2>
        <div className="flex items-center justify-center gap-2 text-gold">
          <Star className="fill-current" />
          <Star className="fill-current" />
          <Star className="fill-current" />
          <Star className="fill-current" />
          <Star className="fill-current" />
        </div>
      </div>
    </section>
  );
};

const FinalCTA = () => {
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-neon-green/5 blur-[120px] rounded-full" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        <h2 className="text-5xl md:text-7xl font-black mb-6 tracking-tighter">
          DOMINGO E SEGUNDA SÃO OS DIAS DE MUDAR <br />
          <span className="text-neon-green italic">SEU JOGO FINANCEIRO.</span>
        </h2>
        <p className="text-xl md:text-2xl text-gray-400 max-w-3xl mx-auto mb-10">
          O grupo opera <span className="text-white font-bold">AO VIVO</span> aos domingos e segundas, das <span className="text-neon-green font-bold">19h às 22h</span>.
          Você recebe os sinais prontos e a orientação exata.
        </p>
        
        <div className="flex flex-col items-center gap-6">
          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-red-500/20 border border-red-500/30 text-red-500 font-bold text-sm animate-pulse">
            <Users className="w-4 h-4" />
            POUCAS VAGAS DISPONÍVEIS
          </div>
          
          <motion.div 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <a 
              href="#planos" 
              className="inline-flex items-center gap-3 bg-neon-green text-black text-2xl font-black px-12 py-8 rounded-3xl glow-green hover:bg-white transition-all"
            >
              ENTRAR NO GRUPO VIP AGORA
              <ArrowRight />
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="py-12 border-t border-white/5 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center gap-12">
          <div className="flex flex-col items-center gap-4 text-center">
            <p className="text-gray-400 font-bold uppercase tracking-widest text-sm">Suporte direto via WhatsApp:</p>
            <a 
              href="https://wa.me/5562981524626" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-3 bg-[#25D366] text-white px-8 py-4 rounded-2xl font-black text-xl hover:scale-105 transition-transform"
              style={{ boxShadow: "0 0 20px rgba(37,211,102,0.5)" }}
            >
              <MessageCircle className="w-6 h-6" />
              Falar no WhatsApp
            </a>
          </div>

          <div className="w-full flex flex-col md:flex-row justify-between items-center gap-8 pt-12 border-t border-white/5">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-neon-green rounded flex items-center justify-center">
                <TrendingUp className="text-black w-4 h-4" />
              </div>
              <span className="text-lg font-bold tracking-tighter">FX VIP WA</span>
            </div>
            
            <div className="flex gap-8 text-xs text-gray-500 font-medium uppercase tracking-widest">
              <a href="#" className="hover:text-white transition-colors">Termos de Uso</a>
              <a href="#" className="hover:text-white transition-colors">Política de Privacidade</a>
            </div>
            
            <p className="text-xs text-gray-600">
              &copy; {new Date().getFullYear()} FX VIP WA. Todos os direitos reservados.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

// --- Main App ---

export default function App() {
  return (
    <div className="min-h-screen selection:bg-neon-green selection:text-black">
      <Navbar />
      <main>
        <Hero />
        <Features />
        <Results />
        <Testimonials />
        <Pricing />
        <ObjectionHandling />
        <FinalCTA />
      </main>
      <Footer />
      <FloatingWhatsApp />
      <StickyCTA />
    </div>
  );
}
