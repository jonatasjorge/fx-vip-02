import { createFileRoute } from "@tanstack/react-router";
import FxVipLanding from "@/components/FxVipLanding";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FX VIP WA - Sinais de Forex ao Vivo" },
      { name: "description", content: "Grupo VIP de sinais de Forex com até 90% de assertividade. Operações ao vivo todo domingo na abertura do mercado." },
      { property: "og:title", content: "FX VIP WA - Sinais de Forex" },
      { property: "og:description", content: "Sinais ao vivo, alta assertividade, suporte via WhatsApp. Entre no grupo e comece a lucrar." },
    ],
  }),
  component: FxVipLanding,
});
