## Mudanças no FX VIP WA

**1. Seção de Planos (Pricing)**
- Remover os 3 planos atuais (Mensal R$350, Semestral R$1.500, Trimestral R$900).
- Substituir por um único plano em destaque:
  - Nome: Plano VIP Mensal
  - Preço: R$67/mês
  - Link de pagamento: `https://pay.cakto.com.br/q9qmxv5`
  - Benefícios: Acesso ao grupo VIP, sinais ao vivo, suporte direto, aula gravada
- Layout centralizado (um único card grande, em vez de grid de 3).

**2. Observação dos dias de operação**
- Adicionar destaque visível com os horários:
  - "Operações ao vivo: Domingo e Segunda, das 19h às 22h"
- Locais onde aparecerá:
  - Abaixo do título da seção de planos (em destaque com ícone de relógio).
  - Atualizar o texto do Hero e do Final CTA que hoje dizem "todos os domingos" / "domingo é o dia" para refletir Domingo e Segunda, 19h–22h.

**3. Arquivo afetado**
- `src/components/FxVipLanding.tsx` (componentes `Pricing`, `Hero`, `FinalCTA`).
